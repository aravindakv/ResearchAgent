import os
from pathlib import Path


def secret(name: str) -> str:
    return Path(f"/run/secrets/{name}").read_text().strip()


# SDKs read these from the environment; load them in-process only (never baked into the image).
for _file, _env in {"openai_api_key": "OPENAI_API_KEY", "langsmith_api_key": "LANGSMITH_API_KEY",
                     "typesafe_api_key": "TYPESAFE_API_KEY"}.items():
    _path = Path(f"/run/secrets/{_file}")
    if _path.exists() and _path.read_text().strip():
        os.environ[_env] = _path.read_text().strip()
if not os.environ.get("LANGSMITH_API_KEY"):
    os.environ["LANGSMITH_TRACING"] = "false"

DB_URL = (f"host={os.environ['POSTGRES_HOST']} dbname={os.environ['POSTGRES_DB']} "
          f"user=app_worker password={secret('pg_worker_password')}")
REDIS_HOST = os.environ["REDIS_HOST"]
REDIS_PASSWORD = secret("redis_password")
CHAT_MODEL = os.environ["OPENAI_CHAT_MODEL"]
EMBED_MODEL = os.environ.get("OPENAI_EMBED_MODEL", "text-embedding-3-small")
MCP_URL = os.environ["MCP_URL"]
MCP_TOKEN = secret("mcp_token")
REPORTS_DIR = os.environ.get("REPORTS_DIR", "/reports")
JOB_TIMEOUT_S = int(os.environ.get("JOB_TIMEOUT_S", "900"))
