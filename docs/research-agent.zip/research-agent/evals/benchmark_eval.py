"""End-to-end benchmark through the running API, recorded as a LangSmith experiment.

Usage (stack running, LANGSMITH_API_KEY set; raise JOBS_PER_HOUR first):
    python evals/benchmark_eval.py
"""
import json
import os
import time
from pathlib import Path

import httpx
from langsmith import Client, evaluate

DATASET = "research-agent-benchmark"
ROOT = Path(__file__).resolve().parent.parent
BASE = os.environ.get("BASE", "https://localhost")
TOKEN = (ROOT / "secrets" / "api_tokens").read_text().splitlines()[0].split(":", 1)[1].strip()
CA = ROOT / "infra" / "caddy-root.crt"
TERMINAL = {"done", "done_low_confidence", "failed", "rejected"}

http = httpx.Client(base_url=BASE, headers={"Authorization": f"Bearer {TOKEN}"},
                    verify=str(CA) if CA.exists() else False, timeout=30)


def target(inputs: dict) -> dict:
    started = time.monotonic()
    job_id = http.post("/research", json={"topic": inputs["topic"]}).raise_for_status().json()["job_id"]
    while True:
        job = http.get(f"/jobs/{job_id}").raise_for_status().json()
        if job["status"] in TERMINAL or time.monotonic() - started > 1200:
            break
        time.sleep(10)
    return {"job_id": job_id, "status": job["status"], "faithfulness": job.get("faithfulness"),
            "seconds": round(time.monotonic() - started)}


def completed(outputs: dict) -> bool:
    return outputs["status"] in ("done", "done_low_confidence")


def faithfulness(outputs: dict) -> dict:
    return {"key": "faithfulness", "score": outputs["faithfulness"] or 0.0}


def duration(outputs: dict) -> dict:
    return {"key": "duration_s", "score": outputs["seconds"]}


def ensure_dataset(client: Client) -> None:
    if client.has_dataset(dataset_name=DATASET):
        return
    topics = json.loads((Path(__file__).parent / "datasets" / "benchmark_topics.json").read_text())
    dataset = client.create_dataset(DATASET, description="End-to-end benchmark topics")
    client.create_examples(dataset_id=dataset.id, inputs=[{"topic": t} for t in topics])


if __name__ == "__main__":
    client = Client()
    ensure_dataset(client)
    evaluate(target, data=DATASET, evaluators=[completed, faithfulness, duration],
             experiment_prefix="benchmark", max_concurrency=2, client=client)
