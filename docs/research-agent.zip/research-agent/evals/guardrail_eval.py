"""Offline evaluation of the topic guardrail, for either decision engine, with LangSmith.

Usage (from the repo root, with OPENAI_API_KEY, LANGSMITH_API_KEY, OPENAI_CHAT_MODEL, and for Jev
TYPESAFE_API_KEY set):
    python evals/guardrail_eval.py --engine jev   [--min-accuracy 0.9]
    python evals/guardrail_eval.py --engine llm
Run both and compare the two experiments side by side in LangSmith (accuracy, error rates, latency, cost).
"""
import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "worker"))
from decisions import make_decisions  # noqa: E402  (same code the worker runs)
from langchain_openai import ChatOpenAI  # noqa: E402
from langsmith import Client, evaluate  # noqa: E402

DATASET = "research-agent-guardrail"


def correct(outputs: dict, reference_outputs: dict) -> bool:
    return outputs["decision"] == reference_outputs["decision"]


def rates(outputs: list[dict], reference_outputs: list[dict]) -> list[dict]:
    pairs = list(zip(outputs, reference_outputs))
    negatives = [o for o, r in pairs if r["decision"] == "reject"]
    positives = [o for o, r in pairs if r["decision"] == "proceed"]
    false_accept = sum(o["decision"] == "proceed" for o in negatives) / max(len(negatives), 1)
    false_reject = sum(o["decision"] == "reject" for o in positives) / max(len(positives), 1)
    return [{"key": "false_accept_rate", "score": false_accept},
            {"key": "false_reject_rate", "score": false_reject}]


def ensure_dataset(client: Client) -> None:
    if client.has_dataset(dataset_name=DATASET):
        return
    path = Path(__file__).parent / "datasets" / "guardrail_cases.jsonl"
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    dataset = client.create_dataset(DATASET, description="Technical-topic guardrail cases")
    client.create_examples(dataset_id=dataset.id,
                           inputs=[{"text": r["input"]} for r in rows],
                           outputs=[{"decision": r["expected"]} for r in rows])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", choices=["jev", "llm"], default="jev")
    parser.add_argument("--min-accuracy", type=float, default=0.0)
    args = parser.parse_args()
    if args.engine == "jev" and not os.environ.get("TYPESAFE_API_KEY"):
        sys.exit("TYPESAFE_API_KEY is not set; use --engine llm or add the key")

    decisions = make_decisions(ChatOpenAI(model=os.environ["OPENAI_CHAT_MODEL"]), engine=args.engine)

    def target(inputs: dict) -> dict:
        d = asyncio.run(decisions.check_topic(inputs["text"]))
        return {"decision": "proceed" if d.proceed else "reject",
                "technical": d.technical, "injection": d.injection}

    client = Client()
    ensure_dataset(client)
    results = evaluate(target, data=DATASET, evaluators=[correct], summary_evaluators=[rates],
                       experiment_prefix=f"guardrail-{args.engine}", max_concurrency=4, client=client,
                       metadata={"decision_engine": args.engine})

    scores = [r["evaluation_results"]["results"][0].score for r in results]
    accuracy = sum(bool(s) for s in scores) / max(len(scores), 1)
    print(f"[{args.engine}] accuracy: {accuracy:.2%} over {len(scores)} cases")
    return 0 if accuracy >= args.min_accuracy else 1


if __name__ == "__main__":
    sys.exit(main())
