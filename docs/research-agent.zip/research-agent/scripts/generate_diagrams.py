#!/usr/bin/env python3
"""Generates every architecture diagram in docs/images/ as a standalone SVG.

Usage: python3 scripts/generate_diagrams.py
Edit coordinates or labels here and re-run; no dependencies beyond the standard library.
"""
from html import escape
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "docs" / "images"
FONT = "font-family=\"'Segoe UI', 'DejaVu Sans', Helvetica, Arial, sans-serif\""
STYLE = {  # fill, stroke, title colour, subtitle colour
    "purple": ("#EEEDFE", "#534AB7", "#3C3489", "#534AB7"),
    "teal":   ("#E1F5EE", "#0F6E56", "#085041", "#0F6E56"),
    "gray":   ("#F1EFE8", "#888780", "#2C2C2A", "#5F5E5A"),
}
GRAY, MUTED = "#5F5E5A", "#5F5E5A"
NET = {"public": "#888780", "edge": "#BA7517", "data": "#0F6E56", "tools": "#534AB7", "egress": "#D85A30"}


def mid(color):
    return "a" + color.lstrip("#")


def markers(colors):
    return "".join(
        f'<marker id="{mid(c)}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" '
        f'orient="auto-start-reverse"><path d="M2 1L8 5L2 9" fill="none" stroke="{c}" stroke-width="1.5" '
        f'stroke-linecap="round" stroke-linejoin="round"/></marker>' for c in colors)


def svg(w, h, title, body, colors=(GRAY,)):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" {FONT} '
            f'role="img">\n<title>{escape(title)}</title>\n<defs>{markers(set(colors) | {GRAY})}</defs>\n'
            f'<rect width="{w}" height="{h}" fill="#FFFFFF"/>\n' + "\n".join(body) + "\n</svg>\n")


def node(x, y, w, h, title, sub=None, style="gray", dashed=False, rx=8):
    fill, stroke, tc, sc = STYLE[style]
    dash = ' stroke-dasharray="4 3"' if dashed else ""
    out = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="0.8"{dash}/>']
    cx = x + w / 2
    if sub:
        out.append(f'<text x="{cx}" y="{y + h / 2 - 10}" text-anchor="middle" dominant-baseline="central" font-size="14" font-weight="600" fill="{tc}">{escape(title)}</text>')
        out.append(f'<text x="{cx}" y="{y + h / 2 + 10}" text-anchor="middle" dominant-baseline="central" font-size="12" fill="{sc}">{escape(sub)}</text>')
    else:
        out.append(f'<text x="{cx}" y="{y + h / 2}" text-anchor="middle" dominant-baseline="central" font-size="13" font-weight="600" fill="{tc}">{escape(title)}</text>')
    return "\n".join(out)


def pill(x, y, w, h, label, style="gray"):
    return node(x, y, w, h, label, style=style, rx=h / 2)


def diamond(cx, cy, hw, hh, label, style="gray"):
    fill, stroke, tc, _ = STYLE[style]
    pts = f"{cx},{cy - hh} {cx + hw},{cy} {cx},{cy + hh} {cx - hw},{cy}"
    return (f'<polygon points="{pts}" fill="{fill}" stroke="{stroke}" stroke-width="0.8"/>'
            f'<text x="{cx}" y="{cy}" text-anchor="middle" dominant-baseline="central" font-size="13" font-weight="600" fill="{tc}">{escape(label)}</text>')


def arrow(*pts, color=GRAY, dashed=False, head=True, width=1.3):
    d = "M" + " L".join(f"{x} {y}" for x, y in pts)
    dash = ' stroke-dasharray="5 4"' if dashed else ""
    end = f' marker-end="url(#{mid(color)})"' if head else ""
    return f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}"{dash}{end}/>'


def label(x, y, s, anchor="middle", size=11, color=MUTED, bg=True, weight="400"):
    out = []
    if bg:
        w = len(s) * size * 0.56 + 6
        bx = {"middle": x - w / 2, "start": x - 3, "end": x - w + 3}[anchor]
        out.append(f'<rect x="{bx:.1f}" y="{y - size / 2 - 3}" width="{w:.1f}" height="{size + 6}" fill="#FFFFFF" opacity="0.92"/>')
    out.append(f'<text x="{x}" y="{y}" text-anchor="{anchor}" dominant-baseline="central" font-size="{size}" font-weight="{weight}" fill="{color}">{escape(s)}</text>')
    return "".join(out)


def container(x, y, w, h, text, right=False):
    tx, anchor = (x + w - 14, "end") if right else (x + 14, "start")
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="none" stroke="#888780" stroke-width="0.8" stroke-dasharray="4 4"/>'
            f'<text x="{tx}" y="{y + 14}" text-anchor="{anchor}" dominant-baseline="central" font-size="12" fill="{MUTED}">{escape(text)}</text>')


def legend(y, text, x=40):
    return f'<text x="{x}" y="{y}" font-size="12" fill="{MUTED}">{escape(text)}</text>'


def write(name, content):
    (OUT / name).write_text(content)
    print("wrote", name)


# ---------------------------------------------------------------- architecture overview
def architecture_overview():
    b = [node(60, 30, 260, 56, "Chat UI + API", "FastAPI, async job queue"),
         arrow((190, 86), (190, 108)),
         node(60, 110, 260, 56, "Input guardrails", "Moderation + Jev topic check"),
         arrow((320, 138), (398, 138)),
         node(400, 110, 240, 56, "Jev (TypeSafe)", "Typed decisions: guard, critic, gate", "teal"),
         arrow((190, 166), (190, 204)),
         container(40, 180, 300, 336, "LangGraph", right=True),
         node(60, 206, 260, 56, "Planner", "Topic to outline + queries", "purple"),
         arrow((190, 262), (190, 284)),
         node(60, 286, 260, 56, "Research + critic loop", "\u21bb until Jev says sufficient", "purple"),
         arrow((190, 342), (190, 364)),
         node(60, 366, 260, 56, "RAG writer", "Retrieve, draft, cite", "purple"),
         arrow((190, 422), (190, 444)),
         node(60, 446, 260, 56, "Evaluation gate", "Jev: support per paragraph", "purple"),
         arrow((190, 502), (190, 538)),
         node(60, 540, 260, 56, "PDF to user", "Stored for download"),
         arrow((320, 314), (398, 314)),
         node(400, 286, 240, 56, "MCP tool server", "Search, fetch, PDF render", "teal"),
         arrow((320, 394), (398, 394)),
         node(400, 366, 240, 56, "Vector DB", "Postgres + pgvector", "teal"),
         arrow((320, 474), (398, 474)),
         node(400, 446, 240, 56, "LangSmith", "Traces, datasets, evals", "teal"),
         legend(626, "Purple: graph nodes \u00b7 Teal: external services \u00b7 Gray: entry and exit")]
    write("architecture-overview.svg", svg(680, 650, "Technical research agent architecture", b))


# ---------------------------------------------------------------- AWS trust zones
def aws_trust_zones():
    b = [node(260, 30, 160, 44, "User (OIDC login)"),
         arrow((340, 74), (340, 118)),
         container(30, 90, 620, 436, "VPC"),
         node(240, 120, 200, 56, "WAF + load balancer", "Public subnet, TLS"),
         arrow((340, 176), (340, 190), (150, 190), (150, 228)),
         container(50, 200, 580, 110, "Private subnet: app services", right=True),
         node(70, 230, 160, 56, "API", "Auth, jobs, status", "purple"),
         arrow((230, 258), (258, 258)),
         node(260, 230, 160, 56, "Worker", "LangGraph runtime", "purple"),
         arrow((420, 258), (448, 258)),
         node(450, 230, 160, 56, "MCP server", "Sandboxed fetcher", "purple"),
         arrow((300, 286), (300, 358)), arrow((380, 286), (380, 358)),
         container(50, 330, 580, 100, "Data tier: no internet route"),
         node(70, 360, 250, 56, "Postgres + pgvector", "Encrypted, TLS only", "teal"),
         node(360, 360, 250, 56, "S3, SQS, Secrets", "Via VPC endpoints", "teal"),
         node(240, 450, 200, 56, "NAT egress", "Firewall, logged"),
         arrow((340, 506), (340, 540), (150, 540), (150, 558)),
         arrow((340, 506), (340, 558)),
         arrow((340, 540), (530, 540), (530, 558)),
         node(70, 560, 160, 56, "OpenAI + TypeSafe", "LLM, embeddings, Jev"),
         node(260, 560, 160, 56, "Open web", "Search + pages"),
         node(450, 560, 160, 56, "LangSmith", "Redacted traces"),
         legend(646, "Purple: app services \u00b7 Teal: data stores \u00b7 Gray: network and external")]
    write("aws-trust-zones.svg", svg(680, 670, "AWS deployment with trust zones", b))


# ---------------------------------------------------------------- agent graph (reference, hybrid)
def agent_graph_reference():
    b = [pill(190, 20, 120, 32, "START"),
         arrow((250, 52), (250, 70)),
         node(140, 72, 220, 56, "guardrail", "Moderation + Jev Nouls", "teal"),
         arrow((360, 100), (488, 100)), label(428, 86, "off-topic or injection", bg=False),
         pill(490, 84, 160, 32, "END: rejected"),
         arrow((250, 128), (250, 158)),
         node(140, 160, 220, 56, "planner", "LLM: title + queries", "purple"),
         arrow((250, 216), (250, 246)),
         node(140, 248, 220, 56, "researcher", "Search, Jev screening, embed"),
         arrow((250, 304), (250, 334)),
         node(140, 336, 220, 56, "critic", "Jev: are sources sufficient?", "teal"),
         arrow((360, 364), (420, 364), (420, 276), (362, 276)),
         label(430, 312, "insufficient:", anchor="start"),
         label(430, 327, "LLM writes new queries", anchor="start"),
         arrow((250, 392), (250, 422)), label(260, 407, "sufficient or cap reached", anchor="start"),
         node(140, 424, 220, 56, "writer", "LLM: cited Markdown draft", "purple"),
         arrow((250, 480), (250, 510)),
         node(140, 512, 220, 56, "evaluator", "Jev: one Noul per paragraph", "teal"),
         arrow((250, 568), (250, 592), (170, 592), (170, 630)),
         arrow((250, 592), (450, 592), (450, 630)),
         label(178, 612, "support \u2265 0.6", anchor="start"),
         label(458, 612, "support < 0.6", anchor="start"),
         node(80, 632, 180, 56, "render", "MCP render_pdf"),
         node(360, 632, 180, 56, "quality_fail", "status: failed"),
         arrow((170, 688), (170, 714)), arrow((450, 688), (450, 714)),
         pill(60, 716, 220, 32, "END: done / low confidence"),
         pill(380, 716, 140, 32, "END: failed"),
         legend(784, "Teal: Jev decisions \u00b7 Purple: LLM generation \u00b7 Gray: tools and control")]
    write("agent-graph-reference.svg", svg(680, 800, "Reference agent graph with Jev and LLM nodes", b))


# ---------------------------------------------------------------- agent graph (full design)
def agent_graph_full():
    b = [pill(240, 20, 120, 32, "START"),
         arrow((300, 52), (300, 68)),
         node(190, 70, 220, 56, "input guardrail", "Moderation + Jev", "teal"),
         arrow((410, 88), (478, 88)), label(444, 79, "ambiguous"),
         arrow((480, 110), (412, 110)), label(444, 121, "answer"),
         node(480, 70, 170, 56, "clarify", "interrupt(), ask user"),
         arrow((190, 98), (162, 98)), label(90, 72, "off-topic"),
         pill(20, 82, 140, 32, "END: rejected"),
         arrow((300, 126), (300, 158)),
         diamond(300, 190, 95, 30, "cache hit?", "teal"),
         arrow((395, 190), (450, 190), (450, 564), (412, 564)), label(420, 180, "yes"),
         arrow((300, 220), (300, 248)), label(310, 234, "no", anchor="start"),
         node(190, 250, 220, 56, "planner", "LLM: outline + queries", "purple"),
         arrow((300, 306), (300, 346)), label(310, 326, "Send, one per section", anchor="start"),
         '<rect x="198" y="356" width="220" height="56" rx="8" fill="#F1EFE8" stroke="#888780" stroke-width="0.8"/>',
         '<rect x="194" y="352" width="220" height="56" rx="8" fill="#F1EFE8" stroke="#888780" stroke-width="0.8"/>',
         node(190, 348, 220, 56, "research_section \u00d7N", "parallel branches"),
         arrow((300, 412), (300, 444)),
         node(190, 446, 220, 56, "research critic", "Jev: sufficient?", "teal"),
         arrow((190, 474), (150, 474), (150, 376), (188, 376)),
         label(142, 418, "gaps: LLM", anchor="end"), label(142, 433, "new queries", anchor="end"),
         arrow((300, 502), (300, 534)),
         node(190, 536, 220, 56, "RAG writer", "per section, hybrid retrieval", "purple"),
         arrow((300, 592), (300, 622)),
         node(190, 624, 220, 56, "reviewer", "LLM rubric critique", "purple"),
         arrow((410, 642), (478, 642)), label(444, 633, "issues"),
         arrow((480, 666), (412, 666)), label(444, 677, "revised"),
         node(480, 624, 170, 56, "reviser", "LLM, max 2 rounds", "purple"),
         arrow((300, 680), (300, 712)), label(310, 696, "approved", anchor="start"),
         node(190, 714, 220, 56, "evaluation gate", "Jev: support per paragraph", "teal"),
         arrow((410, 742), (565, 742), (565, 682)), label(488, 733, "fails: retry once"),
         arrow((190, 742), (90, 742), (90, 790)), label(98, 768, "still failing", anchor="start"),
         pill(20, 792, 140, 32, "END: failed"),
         arrow((300, 770), (300, 800)), label(310, 785, "passes", anchor="start"),
         node(190, 802, 220, 56, "render_pdf", "MCP tool"),
         arrow((300, 858), (300, 878)),
         pill(240, 880, 120, 32, "END: done"),
         legend(944, "Teal: Jev decisions \u00b7 Purple: LLM generation \u00b7 Gray: tools and control")]
    write("agent-graph-full.svg", svg(680, 960, "Full-design agent graph", b))


# ---------------------------------------------------------------- request sequence
def request_sequence():
    parts = [("User", "gray"), ("API", "gray"), ("Postgres", "gray"), ("Redis", "gray"),
             ("Worker", "gray"), ("MCP", "gray"), ("OpenAI", "purple"), ("Jev", "teal")]
    X = {n: 45 + i * 84 for i, (n, _) in enumerate(parts)}
    msgs = [("User", "API", "POST /research", False), ("API", "Postgres", "INSERT job", False),
            ("API", "Redis", "XADD job_id", False), ("API", "User", "202 + job_id", True),
            ("Worker", "Redis", "XREADGROUP", False), ("Worker", "Postgres", "load topic, checkpoint", False),
            ("Worker", "OpenAI", "moderation", False), ("Worker", "Jev", "topic check", False),
            ("Worker", "OpenAI", "plan: title, queries", False),
            "LOOP",
            ("Worker", "MCP", "web_search", False), ("MCP", "Worker", "results", True),
            ("Worker", "Jev", "screen chunks", False), ("Worker", "OpenAI", "embed chunks", False),
            ("Worker", "Postgres", "INSERT chunks", False), ("Worker", "Jev", "sufficient?", False),
            ("Worker", "OpenAI", "new queries, if needed", False),
            "ENDLOOP",
            ("Worker", "OpenAI", "write cited draft", False), ("Worker", "Jev", "paragraph support", False),
            ("Worker", "Postgres", "store scores", False), ("Worker", "MCP", "render_pdf", False),
            ("MCP", "Worker", "PDF bytes", True), ("Worker", "Postgres", "status done", False),
            ("Worker", "Redis", "XACK", False), ("User", "API", "GET PDF", False),
            ("API", "User", "PDF if owner", True)]
    body, y, loop_top = [], 84, None
    colors = {GRAY}
    for m in msgs:
        if m == "LOOP":
            y += 20
            loop_top = y - 36
            continue
        if m == "ENDLOOP":
            body.append(f'<rect x="192" y="{loop_top}" width="484" height="{y - loop_top - 10}" rx="6" fill="none" stroke="#888780" stroke-width="0.8" stroke-dasharray="4 3"/>')
            body.append(f'<rect x="192" y="{loop_top}" width="196" height="18" rx="4" fill="#F1EFE8" stroke="#888780" stroke-width="0.8"/>')
            body.append(f'<text x="200" y="{loop_top + 9}" dominant-baseline="central" font-size="11" font-weight="600" fill="{MUTED}">loop: until sufficient or cap</text>')
            y += 10
            continue
        a, b, text, ret = m
        x1, x2 = X[a], X[b]
        pad = 3 if x2 > x1 else -3
        body.append(arrow((x1 + pad, y), (x2 - pad, y), dashed=ret))
        body.append(label((x1 + x2) / 2, y - 9, text))
        y += 26
    H = y + 10
    head = []
    for n, style in parts:
        head.append(f'<line x1="{X[n]}" y1="52" x2="{X[n]}" y2="{H - 14}" stroke="#B4B2A9" stroke-width="1" stroke-dasharray="3 4"/>')
    for n, style in parts:
        head.append(node(X[n] - 38, 16, 76, 36, n, style=style))
    write("request-sequence.svg", svg(680, H, "Request lifecycle sequence", head + body, colors))


# ---------------------------------------------------------------- data model
def table(x, y, w, title, rows):
    h = 30 + 22 * len(rows)
    out = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="#FFFFFF" stroke="#0F6E56" stroke-width="0.8"/>',
           f'<path d="M{x} {y + 30} L{x} {y + 8} Q{x} {y} {x + 8} {y} L{x + w - 8} {y} Q{x + w} {y} {x + w} {y + 8} L{x + w} {y + 30} Z" fill="#E1F5EE" stroke="#0F6E56" stroke-width="0.8"/>',
           f'<text x="{x + 12}" y="{y + 15}" dominant-baseline="central" font-size="14" font-weight="600" fill="#085041">{escape(title)}</text>']
    for i, (name, typ, key) in enumerate(rows):
        ry = y + 30 + 22 * i + 11
        if i:
            out.append(f'<line x1="{x}" y1="{ry - 11}" x2="{x + w}" y2="{ry - 11}" stroke="#E1F5EE" stroke-width="1"/>')
        out.append(f'<text x="{x + 12}" y="{ry}" dominant-baseline="central" font-size="12" fill="#2C2C2A">{escape(name)}</text>')
        out.append(f'<text x="{x + w - 12}" y="{ry}" text-anchor="end" dominant-baseline="central" font-size="11" fill="{MUTED}">{escape(typ)}{("  " + key) if key else ""}</text>')
    return "\n".join(out)


def data_model():
    b = [table(30, 30, 220, "jobs", [("id", "uuid", "PK"), ("user_id", "text", ""), ("topic", "text", ""),
                                      ("status", "text", ""), ("error", "text", ""), ("created_at", "timestamptz", ""),
                                      ("updated_at", "timestamptz", "")]),
         table(420, 30, 230, "chunks", [("id", "bigint", "PK"), ("job_id", "uuid", "FK"), ("url", "text", ""),
                                         ("content", "text", ""), ("content_hash", "text", ""),
                                         ("embedding", "vector(1536)", ""), ("tsv", "tsvector", "")]),
         table(30, 280, 220, "eval_results", [("job_id", "uuid", "PK, FK"), ("metric", "text", "PK"), ("score", "real", "")]),
         node(420, 280, 230, 56, "lg.* schema", "LangGraph checkpoints", dashed=True),
         arrow((250, 64), (418, 64)), label(334, 54, "1 \u2192 many"),
         arrow((140, 214), (140, 278)), label(150, 246, "1 \u2192 many", anchor="start"),
         label(535, 232, "HNSW index on embedding \u00b7 GIN index on tsv", bg=False),
         legend(396, "Unique (job_id, content_hash) deduplicates chunks \u00b7 metrics: faithfulness, sufficiency")]
    write("data-model.svg", svg(680, 412, "Data model", b))


# ---------------------------------------------------------------- local topology
def local_topology():
    c = NET
    b = [node(20, 30, 120, 56, "User", "browser / curl"),
         node(180, 30, 130, 56, "Caddy", "TLS, headers"),
         node(375, 30, 130, 56, "API", "auth, jobs", "purple"),
         node(290, 140, 140, 56, "Postgres", "pgvector", "teal"),
         node(450, 140, 140, 56, "Redis", "job stream", "teal"),
         node(375, 250, 130, 56, "Worker \u00d72", "LangGraph", "purple"),
         node(180, 250, 150, 56, "reports volume", "PDF files", "teal", dashed=True),
         node(525, 250, 150, 56, "External APIs", "OpenAI, Jev, LangSmith"),
         node(375, 360, 130, 56, "MCP server", "search, fetch, PDF", "purple"),
         node(530, 360, 140, 56, "Web", "Tavily + pages"),
         arrow((140, 58), (178, 58), color=c["public"], width=2),
         arrow((310, 58), (373, 58), color=c["edge"], width=2),
         arrow((420, 86), (380, 138), color=c["data"], width=2),
         arrow((460, 86), (500, 138), color=c["data"], width=2),
         arrow((420, 250), (380, 198), color=c["data"], width=2),
         arrow((460, 250), (500, 198), color=c["data"], width=2),
         arrow((505, 278), (523, 278), color=c["egress"], width=2),
         arrow((440, 306), (440, 358), color=c["tools"], width=2),
         arrow((505, 388), (528, 388), color=c["egress"], width=2),
         arrow((375, 278), (332, 278), dashed=True), label(353, 268, "writes"),
         arrow((255, 250), (255, 110), (395, 110), (395, 88), dashed=True), label(247, 180, "API reads", anchor="end")]
    items = [("public", "public"), ("edge", "edge (internal)"), ("data", "data (internal)"),
             ("tools", "tools (internal)"), ("egress", "egress (internet)")]
    x = 20
    for key, text in items:
        b.append(f'<line x1="{x}" y1="450" x2="{x + 24}" y2="450" stroke="{c[key]}" stroke-width="3"/>')
        b.append(f'<text x="{x + 30}" y="450" dominant-baseline="central" font-size="11" fill="{MUTED}">{escape(text)}</text>')
        x += 30 + len(text) * 6.2 + 18
    b.append(legend(476, "Only Caddy publishes ports (127.0.0.1). Internal networks have no route to the internet.", x=20))
    write("local-topology.svg", svg(680, 494, "Local Docker network topology", b, list(c.values())))


# ---------------------------------------------------------------- evaluation flow
def eval_flow():
    b = [container(15, 20, 320, 410, "Offline, before changes ship"),
         container(345, 20, 320, 410, "Online, on every job"),
         node(30, 50, 140, 56, "Guardrail cases", "labeled jsonl"),
         node(180, 50, 140, 56, "Benchmark topics", "10\u201330 topics"),
         arrow((100, 106), (100, 148)), arrow((250, 106), (250, 148)),
         node(30, 150, 140, 56, "Guardrail eval", "guardrail_eval.py"),
         node(180, 150, 140, 56, "Benchmark eval", "benchmark_eval.py"),
         arrow((100, 206), (140, 248)), arrow((250, 206), (210, 248)),
         node(75, 250, 200, 56, "LangSmith experiments", "Jev vs LLM, run vs run", "teal"),
         arrow((175, 306), (175, 318)),
         diamond(175, 350, 110, 32, "CI threshold met?"),
         label(175, 404, "fail the PR if accuracy drops", bg=False),
         node(405, 50, 200, 56, "Draft", "from the writer", "purple"),
         arrow((505, 106), (505, 148)),
         node(405, 150, 200, 56, "Jev", "one Noul per paragraph", "teal"),
         arrow((505, 206), (505, 218)),
         diamond(505, 250, 110, 30, "share supported"),
         arrow((505, 280), (505, 300), (403, 300), (403, 318)),
         arrow((505, 300), (505, 318)),
         arrow((505, 300), (607, 300), (607, 318)),
         node(355, 320, 96, 56, "done", "\u2265 0.8"),
         node(457, 320, 96, 56, "warning", "0.6 \u2013 0.8"),
         node(559, 320, 96, 56, "failed", "< 0.6"),
         label(505, 404, "failing paragraphs go to the reviser", bg=False)]
    write("eval-flow.svg", svg(680, 446, "Offline evaluation suite and online quality gate", b))


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    for fn in (architecture_overview, aws_trust_zones, agent_graph_reference, agent_graph_full,
               request_sequence, data_model, local_topology, eval_flow):
        fn()
