# Technical Research Agent

A learning project that turns a technical topic typed into a chat into a researched, cited PDF. It combines a LangGraph agent with critic loops, an MCP tool server, RAG over pgvector, input guardrails, an evaluation gate, LangSmith tracing, and a hardened multi-service deployment. It uses two kinds of model: an LLM for generation (planning, writing) and TypeSafe's Jev System One model for fast, typed decisions (guardrail, chunk screening, research sufficiency, faithfulness gate), with an LLM fallback when no TypeSafe key is set.

The repository is meant to be used in two ways. You can **build it yourself** by following the phased implementation guide and only peeking at the reference code when you get stuck, or you can **run the reference implementation** straight away and study it.

## Repository layout

| Path | What it contains |
|---|---|
| `docs/01-architecture.md` | System design: components, request lifecycle, graph, data model, design decisions |
| `docs/02-setup-local.md` | Running the reference implementation on a local Ubuntu machine |
| `docs/03-implementation-guide.md` | Build-it-yourself guide in eight phases, with checkpoints and stretch goals |
| `docs/04-security.md` | Threat model, controls at each layer, and how to verify them |
| `docs/05-evaluation.md` | Guardrail evals, the online quality gate, offline benchmarks, CI |
| `docs/06-cloud-deployment.md` | Moving from Docker Compose to AWS |
| `docs/07-code-walkthrough.md` | File-by-file tour of the reference code |
| `docs/08-jev-decision-model.md` | Why and where Jev replaces LLM calls, thresholds, engine comparison |
| `docs/images/` | All diagrams as SVG, with an index in `docs/images/README.md` (regenerate with `scripts/generate_diagrams.py`) |
| `api/` | FastAPI service: auth, job submission, status, PDF download |
| `worker/` | LangGraph worker: queue consumer, graph, checkpointer, decision engines (`decisions.py`) |
| `mcp_server/` | FastMCP server: web search, page fetch, PDF rendering |
| `infra/` | Postgres schema and roles, Caddy reverse proxy config |
| `evals/` | LangSmith evaluation scripts and datasets |
| `scripts/` | Secret generation, smoke test, isolation checks, diagram generator |

## Diagrams

All diagrams are standalone SVG files in `docs/images/`: the architecture overview, the request sequence, the agent graph (reference and full design), the data model, the local network topology, the AWS trust zones, and the evaluation flow. They render in any Markdown viewer. To change one, edit `scripts/generate_diagrams.py` and run `python3 scripts/generate_diagrams.py`.

![Architecture overview](docs/images/architecture-overview.svg)

*Diagram file: `docs/images/architecture-overview.svg` (linked here as `docs/images/architecture-overview.svg`)*

## Suggested reading order

Start with `docs/01-architecture.md` so you have the whole picture. If you want to build from scratch, continue with `docs/03-implementation-guide.md`, and use `docs/02-setup-local.md` when you reach the containerization phase. If you want to see it working first, go to `docs/02-setup-local.md` and then read `docs/07-code-walkthrough.md` alongside the code. Read `docs/04-security.md` and `docs/05-evaluation.md` before you expose the service to anyone else.

## Quick start (reference implementation)

    make secrets                       # generate internal secrets, enter API keys
    cp .env.example .env && nano .env  # set OPENAI_CHAT_MODEL
    make up                            # build and start everything
    make isolation                     # verify network boundaries and the SSRF guard
    make smoke TOPIC="How does Raft consensus work"

## A note on the reference code

The reference implementation is deliberately minimal: one research loop over the whole topic, vector-only retrieval, and per-paragraph faithfulness from Jev. The implementation guide's stretch goals take it to the full design (per-section fan-out, hybrid search, a reviewer loop, RAGAS metrics, a semantic cache, human-in-the-loop clarification). It has been syntax-checked, and the decision logic has been tested against a mocked Jev client, but LangGraph, the MCP SDK, the LangChain MCP adapters, and `langchain-typesafe` move quickly, so expect to fix small API differences on the first run.
